export class Newsfeed{
    id:number;
    userId:number;
    activity:String;
    date:Date;
}