package com.social.pixogram.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="newsfeed")
@SequenceGenerator(name = "seqnew", initialValue = 1, allocationSize = 100)
public class Newsfeed {

	public Newsfeed() {
	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqnew")
	private long id;
	
	private long userId;
	private String activity;
	private LocalDate date;
	
	public Newsfeed(long userId,String activity){
		this.userId=userId;
		this.activity=activity;
		this.date=java.time.LocalDate.now();
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getActivity() {
		return activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}
}
