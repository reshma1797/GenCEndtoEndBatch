package com.social.pixogram.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.social.pixogram.model.Newsfeed;

public interface NewsfeedRepo extends CrudRepository<Newsfeed,Long>{
	@Query(value="Select n from Newsfeed n where n.userId=?1")
	List<Newsfeed> findAllByUserId(long userId);

}
