import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admintech',
  templateUrl: './admintech.component.html',
  styleUrls: ['./admintech.component.css']
})
export class AdmintechComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
