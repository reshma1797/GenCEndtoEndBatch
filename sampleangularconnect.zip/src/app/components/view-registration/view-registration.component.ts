import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-view-registration',
  templateUrl: './view-registration.component.html',
  styleUrls: ['./view-registration.component.css']
})
export class ViewRegistrationComponent implements OnInit {
  public userReg;
  constructor(private userService:UserService,private route: ActivatedRoute) { }

  ngOnInit() {
    this.getUserReg(this.route.snapshot.params.id);
  }
  getUserReg(id:number){
    this.userService.getUser(id).subscribe(
      data=>{
        this.userReg=data;
      },
      err=>console.error(err),
      ()=>console.log('User loaded')
    );
  }

}
