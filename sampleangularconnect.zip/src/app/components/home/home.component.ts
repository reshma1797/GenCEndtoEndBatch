import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import {FormGroup,FormControl,Validators} from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  userform:FormGroup;
  validMessage:string="";
  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userform=new FormGroup({
      name: new FormControl('',Validators.required),
      email:new FormControl('',Validators.required),
      password:new FormControl('',Validators.required),
      phone:new FormControl('',Validators.required),
      Reg_date:new FormControl('',Validators.required),
      price:new FormControl('',Validators.required),
    });
  }
  submitRegistration(){
    if(this.userform.valid){
      this.validMessage ="Succesfully Regitered. ThankYou";
      this.userService.createUserRegistration(this.userform.value).subscribe(
        data=>{
          this.userform.reset();
          return true;
        },
        error=>{
          return Observable.throw(error);
        }
      )
    }else{
      this.validMessage="Please fill out the form befor submitting";
    }
  }

}
