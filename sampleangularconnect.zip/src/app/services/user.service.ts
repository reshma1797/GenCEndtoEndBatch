import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';

const httpOptions={
  headers:new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }

  getUsers(){
    return this.http.get('/server/api');
  }
  getUser(id: number){
    return this.http.get('/server/api/'+id);

  }
  createUserRegistration(user){
    let body=JSON.stringify(user);
    return this.http.post('/server/api', body,httpOptions);
  }
}
