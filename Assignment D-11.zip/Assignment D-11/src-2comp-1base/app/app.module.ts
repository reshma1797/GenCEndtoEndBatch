import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { BaseComponent } from './base.component';

import { DerivedComponent } from './derived.component';

import { DeriveComponent } from './derive.component';


@NgModule({
  declarations: [
    AppComponent, BaseComponent, DerivedComponent, DeriveComponent ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
